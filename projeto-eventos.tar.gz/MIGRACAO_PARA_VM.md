# 🚀 Guia Completo: Migração do Projeto Local para VM

Este guia detalha todos os passos para migrar o projeto completo (código, banco de dados e configurações) da máquina local para a VM.

**Informações da VM:**
- **IP:** 177.44.248.110
- **Usuário:** univates
- **Senha:** eventos
- **SSH:** `ssh univates@177.44.248.110`

---

## 📋 Pré-requisitos

### Na VM (será instalado):
- Ubuntu/Debian Linux
- PostgreSQL
- .NET 8 SDK
- PHP 8.1+
- Composer
- Nginx ou Apache (para servir o portal)

---

## 🔧 FASE 1: Preparação da VM

### 1.1 Conectar via SSH
```bash
ssh univates@177.44.248.110
# Senha: eventos
```

### 1.2 Atualizar o sistema
```bash
sudo apt update && sudo apt upgrade -y
```

### 1.3 Instalar PostgreSQL
```bash
sudo apt install postgresql postgresql-contrib -y
sudo systemctl start postgresql
sudo systemctl enable postgresql
```

### 1.4 Instalar .NET 8 SDK
```bash
# Adicionar repositório Microsoft
wget https://packages.microsoft.com/config/ubuntu/22.04/packages-microsoft-prod.deb -O packages-microsoft-prod.deb
sudo dpkg -i packages-microsoft-prod.deb
rm packages-microsoft-prod.deb

# Instalar .NET 8 SDK
sudo apt update
sudo apt install -y dotnet-sdk-8.0
```

### 1.5 Instalar PHP e Composer
```bash
sudo apt install -y php8.1 php8.1-pgsql php8.1-mbstring php8.1-xml php8.1-curl -y

# Instalar Composer
curl -sS https://getcomposer.org/installer | php
sudo mv composer.phar /usr/local/bin/composer
sudo chmod +x /usr/local/bin/composer
```

### 1.6 Instalar Nginx
```bash
sudo apt install nginx -y
sudo systemctl start nginx
sudo systemctl enable nginx
```

---

## 🗄️ FASE 2: Configuração do Banco de Dados

### 2.1 Criar banco de dados e usuário
```bash
sudo -u postgres psql
```

No PostgreSQL:
```sql
-- Criar banco de dados
CREATE DATABASE eventos_db;

-- Criar usuário
CREATE USER eventos WITH PASSWORD 'eventos123';

-- Dar permissões
GRANT ALL PRIVILEGES ON DATABASE eventos_db TO eventos;

-- Conectar ao banco
\c eventos_db

-- Dar permissões no schema
GRANT ALL ON SCHEMA public TO eventos;
ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT ALL ON TABLES TO eventos;
ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT ALL ON SEQUENCES TO eventos;

-- Sair
\q
```

### 2.2 Configurar PostgreSQL para aceitar conexões externas
```bash
sudo nano /etc/postgresql/*/main/postgresql.conf
```

Encontrar e alterar:
```
listen_addresses = '*'
```

```bash
sudo nano /etc/postgresql/*/main/pg_hba.conf
```

Adicionar no final:
```
host    all             all             0.0.0.0/0               md5
```

Reiniciar PostgreSQL:
```bash
sudo systemctl restart postgresql
```

### 2.3 Exportar banco de dados local (na sua máquina)

**No Windows (PowerShell):**
```powershell
# Exportar schema e dados
pg_dump -U postgres -h localhost -d eventos_db -F c -f eventos_db_backup.dump

# Ou exportar como SQL
pg_dump -U postgres -h localhost -d eventos_db > eventos_db_backup.sql
```

**No Linux/Mac:**
```bash
pg_dump -U postgres -h localhost -d eventos_db -F c -f eventos_db_backup.dump
# Ou
pg_dump -U postgres -h localhost -d eventos_db > eventos_db_backup.sql
```

### 2.4 Transferir e importar banco na VM

**Transferir arquivo:**
```bash
# Na sua máquina local
scp eventos_db_backup.dump univates@177.44.248.110:~/
# Ou se for SQL
scp eventos_db_backup.sql univates@177.44.248.110:~/
```

**Na VM, importar:**
```bash
# Se for dump binário
pg_restore -U postgres -d eventos_db -h localhost eventos_db_backup.dump

# Se for SQL
psql -U postgres -d eventos_db -h localhost < eventos_db_backup.sql
```

---

## 📦 FASE 3: Transferência do Código

### 3.1 Preparar código local (remover arquivos desnecessários)

Na sua máquina local, criar um arquivo `.gitignore` temporário ou usar o existente, e depois:

```bash
# Criar arquivo .tar.gz excluindo node_modules, vendor, bin, obj, etc.
tar --exclude='node_modules' \
    --exclude='vendor' \
    --exclude='bin' \
    --exclude='obj' \
    --exclude='.vs' \
    --exclude='.idea' \
    --exclude='*.db' \
    --exclude='*.sqlite' \
    -czf projeto-eventos.tar.gz .
```

### 3.2 Transferir código para VM
```bash
# Na sua máquina local
scp projeto-eventos.tar.gz univates@177.44.248.110:~/
```

### 3.3 Extrair código na VM
```bash
# Na VM
cd ~
mkdir -p ~/projeto-eventos
cd ~/projeto-eventos
tar -xzf ~/projeto-eventos.tar.gz
```

---

## ⚙️ FASE 4: Configuração dos Serviços

### 4.1 Executar script de configuração automática (RECOMENDADO)

```bash
cd ~/projeto-eventos
chmod +x configurar-vm.sh
./configurar-vm.sh
```

Este script irá automaticamente:
- ✅ Instalar dependências PHP (composer install)
- ✅ Criar arquivos de configuração de banco
- ✅ Configurar appsettings.json dos serviços .NET
- ✅ Atualizar portal para usar IP da VM
- ✅ Verificar conexão com banco

**OU configure manualmente seguindo os passos abaixo:**

### 4.2 Configurar Auth Service manualmente

```bash
cd ~/projeto-eventos/services/auth-service
```

Criar/editar `appsettings.json`:
```json
{
  "ConnectionStrings": {
    "DefaultConnection": "Host=localhost;Port=5432;Database=eventos_db;Username=eventos;Password=eventos123"
  },
  "Jwt": {
    "Secret": "MinhaChaveSecretaSuperSeguraParaJWT2024!@#$%",
    "Issuer": "EventosAuth",
    "Audience": "EventosApp"
  },
  "Logging": {
    "LogLevel": {
      "Default": "Information",
      "Microsoft.AspNetCore": "Warning"
    }
  },
  "AllowedHosts": "*"
}
```

**Nota:** O `Program.cs` já foi atualizado para aceitar conexões externas (`0.0.0.0`).

### 4.3 Configurar Eventos Service manualmente (se necessário)

```bash
cd ~/projeto-eventos/services/eventos-service
```

Criar/editar `appsettings.json` (mesmo formato do Auth Service).

**Nota:** O `Program.cs` já foi atualizado para aceitar conexões externas.

### 4.4 Configurar Inscrições Service (PHP)

```bash
cd ~/projeto-eventos/services/inscricoes-service
```

**Nota:** O script `configurar-vm.sh` já cria este arquivo automaticamente.

Criar arquivo `config/database.php` (se não existir):
```php
<?php
function getDatabaseConnection() {
    $host = 'localhost';
    $dbname = 'eventos_db';
    $username = 'eventos';
    $password = 'eventos123';
    $port = '5432';
    
    try {
        $dsn = "pgsql:host=$host;port=$port;dbname=$dbname";
        $pdo = new PDO($dsn, $username, $password);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        return $pdo;
    } catch (PDOException $e) {
        die("Erro de conexão: " . $e->getMessage());
    }
}
?>
```

Instalar dependências:
```bash
composer install
```

**Nota:** O script `configurar-vm.sh` já instala as dependências.

### 4.5 Configurar Certificados Service (PHP)

```bash
cd ~/projeto-eventos/services/certificados-service
```

**Nota:** O script `configurar-vm.sh` já cria o arquivo de configuração.

Instalar dependências:
```bash
composer install
```

### 4.6 Configurar Email Service (PHP)

```bash
cd ~/projeto-eventos/services/email-service
```

**Nota:** O script `configurar-vm.sh` já cria o arquivo de configuração.

Instalar dependências:
```bash
composer install
```

### 4.7 Configurar Portal (Frontend)

```bash
cd ~/projeto-eventos/portal
```

**Nota:** O script `configurar-vm.sh` já atualiza o `api.js` automaticamente.

Se precisar fazer manualmente, editar `js/api.js` e alterar as URLs:

```javascript
const API_CONFIG = {
    AUTH: 'http://177.44.248.110:5001/api',
    EVENTOS: 'http://177.44.248.110:5002/api',
    INSCRICOES: 'http://177.44.248.110:8001/api/inscricoes',
    CERTIFICADOS: 'http://177.44.248.110:8002/api/certificados',
    EMAIL: 'http://177.44.248.110:8003/api/email'
};
```

---

## 🌐 FASE 5: Configuração do Nginx

### 5.1 Criar configuração do Nginx

```bash
sudo nano /etc/nginx/sites-available/eventos
```

Adicionar:
```nginx
server {
    listen 80;
    server_name 177.44.248.110;

    # Portal Frontend
    location / {
        root /home/univates/projeto-eventos/portal;
        index index.html;
        try_files $uri $uri/ /index.html;
    }

    # Proxy para Auth Service
    location /api/auth/ {
        proxy_pass http://localhost:5001/api/auth/;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection keep-alive;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }

    # Proxy para Eventos Service
    location /api/eventos/ {
        proxy_pass http://localhost:5002/api/eventos/;
        proxy_http_version 1.1;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    }

    # Proxy para Inscrições Service
    location /api/inscricoes/ {
        proxy_pass http://localhost:8001/api/inscricoes/;
        proxy_http_version 1.1;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    }

    # Proxy para Certificados Service
    location /api/certificados/ {
        proxy_pass http://localhost:8002/api/certificados/;
        proxy_http_version 1.1;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    }

    # Proxy para Email Service
    location /api/email/ {
        proxy_pass http://localhost:8003/api/email/;
        proxy_http_version 1.1;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    }
}
```

Ativar site:
```bash
sudo ln -s /etc/nginx/sites-available/eventos /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl reload nginx
```

---

## 🔥 FASE 6: Configurar Firewall

### 6.1 Abrir portas necessárias
```bash
sudo ufw allow 22/tcp    # SSH
sudo ufw allow 80/tcp    # HTTP
sudo ufw allow 443/tcp   # HTTPS (se usar SSL depois)
sudo ufw allow 5001/tcp  # Auth Service
sudo ufw allow 5002/tcp  # Eventos Service
sudo ufw allow 8001/tcp  # Inscrições Service
sudo ufw allow 8002/tcp  # Certificados Service
sudo ufw allow 8003/tcp  # Email Service
sudo ufw enable
```

---

## 🚀 FASE 7: Criar Scripts de Inicialização

### 7.1 Usar script de inicialização

**Nota:** O script `iniciar-servicos-vm.sh` já foi criado no projeto.

Tornar executável e usar:
```bash
cd ~/projeto-eventos
chmod +x iniciar-servicos-vm.sh
./iniciar-servicos-vm.sh
```

**OU criar manualmente:**

```bash
nano ~/projeto-eventos/iniciar-servicos.sh
```

Adicionar:
```bash
#!/bin/bash

# Cores para output
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

echo -e "${GREEN}Iniciando serviços do Sistema de Eventos...${NC}"

# Auth Service
echo -e "${YELLOW}Iniciando Auth Service...${NC}"
cd ~/projeto-eventos/services/auth-service
dotnet run > /tmp/auth-service.log 2>&1 &
echo $! > /tmp/auth-service.pid
sleep 3

# Eventos Service
echo -e "${YELLOW}Iniciando Eventos Service...${NC}"
cd ~/projeto-eventos/services/eventos-service
dotnet run > /tmp/eventos-service.log 2>&1 &
echo $! > /tmp/eventos-service.pid
sleep 3

# Inscrições Service
echo -e "${YELLOW}Iniciando Inscrições Service...${NC}"
cd ~/projeto-eventos/services/inscricoes-service
php -S 0.0.0.0:8001 router.php > /tmp/inscricoes-service.log 2>&1 &
echo $! > /tmp/inscricoes-service.pid
sleep 2

# Certificados Service
echo -e "${YELLOW}Iniciando Certificados Service...${NC}"
cd ~/projeto-eventos/services/certificados-service
php -S 0.0.0.0:8002 router.php > /tmp/certificados-service.log 2>&1 &
echo $! > /tmp/certificados-service.pid
sleep 2

# Email Service
echo -e "${YELLOW}Iniciando Email Service...${NC}"
cd ~/projeto-eventos/services/email-service
php -S 0.0.0.0:8003 index.php > /tmp/email-service.log 2>&1 &
echo $! > /tmp/email-service.pid
sleep 2

# Email Worker
echo -e "${YELLOW}Iniciando Email Worker...${NC}"
cd ~/projeto-eventos/services/email-service
php worker.php > /tmp/email-worker.log 2>&1 &
echo $! > /tmp/email-worker.pid

echo -e "${GREEN}✓ Todos os serviços iniciados!${NC}"
echo -e "${GREEN}Verificar logs em /tmp/*.log${NC}"
```

Tornar executável:
```bash
chmod +x ~/projeto-eventos/iniciar-servicos.sh
```

### 7.2 Usar script para parar serviços

**Nota:** O script `parar-servicos-vm.sh` já foi criado no projeto.

```bash
cd ~/projeto-eventos
./parar-servicos-vm.sh
```

**OU criar manualmente:**

```bash
nano ~/projeto-eventos/parar-servicos.sh
```

Adicionar:
```bash
#!/bin/bash

echo "Parando serviços..."

# Parar serviços pelos PIDs
for pidfile in /tmp/*-service.pid /tmp/*-worker.pid; do
    if [ -f "$pidfile" ]; then
        pid=$(cat "$pidfile")
        if ps -p $pid > /dev/null 2>&1; then
            kill $pid
            echo "Parado: $pidfile (PID: $pid)"
        fi
        rm "$pidfile"
    fi
done

# Matar processos por porta (fallback)
pkill -f "dotnet run"
pkill -f "php -S"

echo "Serviços parados."
```

Tornar executável:
```bash
chmod +x ~/projeto-eventos/parar-servicos.sh
```

---

## ✅ FASE 8: Testar e Verificar

### 8.1 Executar configuração automática (se ainda não fez)
```bash
cd ~/projeto-eventos
./configurar-vm.sh
```

### 8.2 Iniciar serviços
```bash
cd ~/projeto-eventos
./iniciar-servicos-vm.sh
```

### 8.3 Verificar se estão rodando
```bash
# Ver processos
ps aux | grep -E "dotnet|php"

# Ver portas
sudo netstat -tlnp | grep -E "5001|5002|8001|8002|8003"

# Ver logs
tail -f /tmp/auth-service.log
tail -f /tmp/eventos-service.log
```

### 8.4 Testar endpoints

**Do seu computador local:**
```bash
# Testar Auth Service
curl http://177.44.248.110:5001/swagger

# Testar Eventos Service
curl http://177.44.248.110:5002/api/eventos

# Testar Portal
curl http://177.44.248.110/
```

### 8.5 Acessar via navegador

- **Portal:** http://177.44.248.110
- **Auth Swagger:** http://177.44.248.110:5001/swagger
- **Eventos Swagger:** http://177.44.248.110:5002/swagger
- **Inscrições Swagger:** http://177.44.248.110:8001/swagger
- **Certificados Swagger:** http://177.44.248.110:8002/swagger

---

## 🔄 FASE 9: Configurar Serviços como Systemd (Opcional - Recomendado)

Para que os serviços iniciem automaticamente após reinicialização:

### 9.1 Criar service para Auth Service

```bash
sudo nano /etc/systemd/system/auth-service.service
```

Adicionar:
```ini
[Unit]
Description=Auth Service - Sistema de Eventos
After=network.target postgresql.service

[Service]
Type=simple
User=univates
WorkingDirectory=/home/univates/projeto-eventos/services/auth-service
ExecStart=/usr/bin/dotnet run
Restart=always
RestartSec=10
StandardOutput=journal
StandardError=journal

[Install]
WantedBy=multi-user.target
```

### 9.2 Criar service para Eventos Service

```bash
sudo nano /etc/systemd/system/eventos-service.service
```

Adicionar:
```ini
[Unit]
Description=Eventos Service - Sistema de Eventos
After=network.target postgresql.service

[Service]
Type=simple
User=univates
WorkingDirectory=/home/univates/projeto-eventos/services/eventos-service
ExecStart=/usr/bin/dotnet run
Restart=always
RestartSec=10
StandardOutput=journal
StandardError=journal

[Install]
WantedBy=multi-user.target
```

### 9.3 Criar service para Inscrições Service

```bash
sudo nano /etc/systemd/system/inscricoes-service.service
```

Adicionar:
```ini
[Unit]
Description=Inscrições Service - Sistema de Eventos
After=network.target postgresql.service

[Service]
Type=simple
User=univates
WorkingDirectory=/home/univates/projeto-eventos/services/inscricoes-service
ExecStart=/usr/bin/php -S 0.0.0.0:8001 router.php
Restart=always
RestartSec=10
StandardOutput=journal
StandardError=journal

[Install]
WantedBy=multi-user.target
```

### 9.4 Criar service para Certificados Service

```bash
sudo nano /etc/systemd/system/certificados-service.service
```

Adicionar:
```ini
[Unit]
Description=Certificados Service - Sistema de Eventos
After=network.target postgresql.service

[Service]
Type=simple
User=univates
WorkingDirectory=/home/univates/projeto-eventos/services/certificados-service
ExecStart=/usr/bin/php -S 0.0.0.0:8002 router.php
Restart=always
RestartSec=10
StandardOutput=journal
StandardError=journal

[Install]
WantedBy=multi-user.target
```

### 9.5 Criar service para Email Service

```bash
sudo nano /etc/systemd/system/email-service.service
```

Adicionar:
```ini
[Unit]
Description=Email Service - Sistema de Eventos
After=network.target postgresql.service

[Service]
Type=simple
User=univates
WorkingDirectory=/home/univates/projeto-eventos/services/email-service
ExecStart=/usr/bin/php -S 0.0.0.0:8003 index.php
Restart=always
RestartSec=10
StandardOutput=journal
StandardError=journal

[Install]
WantedBy=multi-user.target
```

### 9.6 Criar service para Email Worker

```bash
sudo nano /etc/systemd/system/email-worker.service
```

Adicionar:
```ini
[Unit]
Description=Email Worker - Sistema de Eventos
After=network.target postgresql.service email-service.service

[Service]
Type=simple
User=univates
WorkingDirectory=/home/univates/projeto-eventos/services/email-service
ExecStart=/usr/bin/php worker.php
Restart=always
RestartSec=10
StandardOutput=journal
StandardError=journal

[Install]
WantedBy=multi-user.target
```

### 9.7 Ativar e iniciar serviços

```bash
sudo systemctl daemon-reload
sudo systemctl enable auth-service
sudo systemctl enable eventos-service
sudo systemctl enable inscricoes-service
sudo systemctl enable certificados-service
sudo systemctl enable email-service
sudo systemctl enable email-worker

sudo systemctl start auth-service
sudo systemctl start eventos-service
sudo systemctl start inscricoes-service
sudo systemctl start certificados-service
sudo systemctl start email-service
sudo systemctl start email-worker
```

### 9.8 Verificar status

```bash
sudo systemctl status auth-service
sudo systemctl status eventos-service
sudo systemctl status inscricoes-service
sudo systemctl status certificados-service
sudo systemctl status email-service
sudo systemctl status email-worker
```

---

## 📝 Checklist Final

- [ ] PostgreSQL instalado e configurado
- [ ] Banco de dados criado e importado
- [ ] .NET 8 SDK instalado
- [ ] PHP 8.1+ e Composer instalados
- [ ] Código transferido para VM
- [ ] Configurações atualizadas (IPs, conexões)
- [ ] Dependências instaladas (composer install)
- [ ] Nginx configurado
- [ ] Firewall configurado
- [ ] Serviços iniciados e testados
- [ ] Systemd services configurados (opcional)
- [ ] Acesso via navegador funcionando

---

## 🔧 Comandos Úteis

### Ver logs dos serviços
```bash
# Logs do systemd
sudo journalctl -u auth-service -f
sudo journalctl -u eventos-service -f

# Logs dos scripts
tail -f /tmp/auth-service.log
```

### Reiniciar serviços
```bash
sudo systemctl restart auth-service
sudo systemctl restart eventos-service
```

### Parar todos os serviços
```bash
~/projeto-eventos/parar-servicos.sh
```

### Iniciar todos os serviços
```bash
~/projeto-eventos/iniciar-servicos-vm.sh
```

### Executar configuração automática
```bash
~/projeto-eventos/configurar-vm.sh
```

---

## ⚠️ Troubleshooting

### Serviço não inicia
```bash
# Verificar logs
sudo journalctl -u auth-service -n 50

# Verificar se porta está em uso
sudo netstat -tlnp | grep 5001
```

### Erro de conexão com banco
```bash
# Testar conexão
psql -U eventos -d eventos_db -h localhost

# Verificar se PostgreSQL está rodando
sudo systemctl status postgresql
```

### Erro 502 Bad Gateway (Nginx)
- Verificar se serviços estão rodando
- Verificar configuração do Nginx
- Verificar logs: `sudo tail -f /var/log/nginx/error.log`

---

**Última atualização:** 2024

