#!/bin/bash

# Script de configuração rápida para VM
# Executa todas as configurações necessárias após transferir o código

GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m'

BASE_DIR="$HOME/projeto-eventos"

echo -e "${GREEN}========================================${NC}"
echo -e "${GREEN}  Configuração do Sistema de Eventos${NC}"
echo -e "${GREEN}========================================${NC}"
echo ""

# Verificar se está no diretório correto
if [ ! -d "$BASE_DIR" ]; then
    echo -e "${RED}Erro: Execute este script dentro do diretório projeto-eventos${NC}"
    exit 1
fi

# 1. Instalar dependências PHP
echo -e "${YELLOW}[1/6] Instalando dependências PHP...${NC}"
cd "$BASE_DIR/services/inscricoes-service"
if [ -f "composer.json" ]; then
    composer install --no-interaction
    echo -e "${GREEN}✓ Inscrições Service${NC}"
fi

cd "$BASE_DIR/services/certificados-service"
if [ -f "composer.json" ]; then
    composer install --no-interaction
    echo -e "${GREEN}✓ Certificados Service${NC}"
fi

cd "$BASE_DIR/services/email-service"
if [ -f "composer.json" ]; then
    composer install --no-interaction
    echo -e "${GREEN}✓ Email Service${NC}"
fi

# 2. Criar arquivos de configuração de banco (se não existirem)
echo -e "${YELLOW}[2/6] Configurando arquivos de banco de dados...${NC}"

# Inscrições Service
if [ ! -f "$BASE_DIR/services/inscricoes-service/config/database.php" ]; then
    cat > "$BASE_DIR/services/inscricoes-service/config/database.php" << 'EOF'
<?php
function getDatabaseConnection() {
    $host = 'localhost';
    $dbname = 'eventos_db';
    $username = 'eventos';
    $password = 'eventos123';
    $port = '5432';
    
    try {
        $dsn = "pgsql:host=$host;port=$port;dbname=$dbname";
        $pdo = new PDO($dsn, $username, $password);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        return $pdo;
    } catch (PDOException $e) {
        die("Erro de conexão: " . $e->getMessage());
    }
}
?>
EOF
    echo -e "${GREEN}✓ Criado: inscricoes-service/config/database.php${NC}"
fi

# Certificados Service
if [ ! -f "$BASE_DIR/services/certificados-service/config/database.php" ]; then
    cp "$BASE_DIR/services/inscricoes-service/config/database.php" "$BASE_DIR/services/certificados-service/config/database.php"
    echo -e "${GREEN}✓ Criado: certificados-service/config/database.php${NC}"
fi

# Email Service
if [ ! -f "$BASE_DIR/services/email-service/config/database.php" ]; then
    cp "$BASE_DIR/services/inscricoes-service/config/database.php" "$BASE_DIR/services/email-service/config/database.php"
    echo -e "${GREEN}✓ Criado: email-service/config/database.php${NC}"
fi

# 3. Configurar appsettings.json dos serviços .NET
echo -e "${YELLOW}[3/6] Configurando serviços .NET...${NC}"

# Auth Service
if [ -f "$BASE_DIR/services/auth-service/appsettings.json" ]; then
    # Backup do original
    cp "$BASE_DIR/services/auth-service/appsettings.json" "$BASE_DIR/services/auth-service/appsettings.json.bak"
    
    # Criar novo com configuração da VM
    cat > "$BASE_DIR/services/auth-service/appsettings.json" << 'EOF'
{
  "ConnectionStrings": {
    "DefaultConnection": "Host=localhost;Port=5432;Database=eventos_db;Username=eventos;Password=eventos123"
  },
  "Jwt": {
    "Secret": "MinhaChaveSecretaSuperSeguraParaJWT2024!@#$%",
    "Issuer": "EventosAuth",
    "Audience": "EventosApp"
  },
  "Logging": {
    "LogLevel": {
      "Default": "Information",
      "Microsoft.AspNetCore": "Warning"
    }
  },
  "AllowedHosts": "*"
}
EOF
    echo -e "${GREEN}✓ Configurado: auth-service/appsettings.json${NC}"
fi

# Eventos Service
if [ -f "$BASE_DIR/services/eventos-service/appsettings.json" ]; then
    cp "$BASE_DIR/services/eventos-service/appsettings.json" "$BASE_DIR/services/eventos-service/appsettings.json.bak"
    
    cat > "$BASE_DIR/services/eventos-service/appsettings.json" << 'EOF'
{
  "ConnectionStrings": {
    "DefaultConnection": "Host=localhost;Port=5432;Database=eventos_db;Username=eventos;Password=eventos123"
  },
  "Jwt": {
    "Secret": "MinhaChaveSecretaSuperSeguraParaJWT2024!@#$%",
    "Issuer": "EventosAuth",
    "Audience": "EventosApp"
  },
  "Logging": {
    "LogLevel": {
      "Default": "Information",
      "Microsoft.AspNetCore": "Warning"
    }
  },
  "AllowedHosts": "*"
}
EOF
    echo -e "${GREEN}✓ Configurado: eventos-service/appsettings.json${NC}"
fi

# 4. Atualizar api.js do portal para usar IP da VM
echo -e "${YELLOW}[4/6] Configurando portal para VM...${NC}"
if [ -f "$BASE_DIR/portal/js/api.js" ]; then
    # Backup
    cp "$BASE_DIR/portal/js/api.js" "$BASE_DIR/portal/js/api.js.local"
    
    # Usar api-vm.js se existir, senão atualizar api.js
    if [ -f "$BASE_DIR/portal/js/api-vm.js" ]; then
        cp "$BASE_DIR/portal/js/api-vm.js" "$BASE_DIR/portal/js/api.js"
        echo -e "${GREEN}✓ Portal configurado para VM${NC}"
    else
        # Atualizar manualmente
        sed -i "s|http://localhost:5001|http://177.44.248.110:5001|g" "$BASE_DIR/portal/js/api.js"
        sed -i "s|http://localhost:5002|http://177.44.248.110:5002|g" "$BASE_DIR/portal/js/api.js"
        sed -i "s|http://localhost:8001|http://177.44.248.110:8001|g" "$BASE_DIR/portal/js/api.js"
        sed -i "s|http://localhost:8002|http://177.44.248.110:8002|g" "$BASE_DIR/portal/js/api.js"
        sed -i "s|http://localhost:8003|http://177.44.248.110:8003|g" "$BASE_DIR/portal/js/api.js"
        echo -e "${GREEN}✓ Portal atualizado para usar IP da VM${NC}"
    fi
fi

# 5. Tornar scripts executáveis
echo -e "${YELLOW}[5/6] Configurando permissões dos scripts...${NC}"
chmod +x "$BASE_DIR/iniciar-servicos-vm.sh" 2>/dev/null
chmod +x "$BASE_DIR/parar-servicos-vm.sh" 2>/dev/null
chmod +x "$BASE_DIR/configurar-vm.sh" 2>/dev/null
echo -e "${GREEN}✓ Scripts configurados${NC}"

# 6. Verificar conexão com banco
echo -e "${YELLOW}[6/6] Verificando conexão com banco de dados...${NC}"
if psql -U eventos -d eventos_db -h localhost -c "SELECT 1;" > /dev/null 2>&1; then
    echo -e "${GREEN}✓ Conexão com banco OK${NC}"
else
    echo -e "${RED}✗ Erro ao conectar no banco. Verifique as credenciais.${NC}"
    echo -e "${YELLOW}  Execute: psql -U eventos -d eventos_db -h localhost${NC}"
fi

echo ""
echo -e "${GREEN}========================================${NC}"
echo -e "${GREEN}  Configuração Concluída!${NC}"
echo -e "${GREEN}========================================${NC}"
echo ""
echo -e "Próximos passos:"
echo -e "1. Importar banco de dados (se ainda não fez)"
echo -e "2. Executar: ${YELLOW}./iniciar-servicos-vm.sh${NC}"
echo -e "3. Acessar: ${YELLOW}http://177.44.248.110${NC}"


